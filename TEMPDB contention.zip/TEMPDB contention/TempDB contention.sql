-- CREATE A STORED PROCEDURE
if exists(select * from sys.objects where name = 'ProcTest')
drop proc ProcTest
go 
CREATE PROC ProcTest
AS
BEGIN
CREATE TABLE #t1
(
  c1 INT, 
  c2 INT);
INSERT INTO #t1
       SELECT TOP 20 column_id, 
                     system_type_id
       FROM sys.all_columns WITH(NOLOCK);
END

-- STRESS TEST
use AdventureWorks2019
DECLARE @i INT;
SET @i = 1;
WHILE @i <= 100
    BEGIN
        EXEC ProcTest;
        SET @i = @i + 1;
    END

-- CHECK THE TEMPDB CONTENTION, PAGELATCH_XX

SELECT r.session_id, r.wait_type, r.wait_resource, r.command, 
    [object] = OBJECT_NAME(p.[object_id],p.database_id)
  FROM sys.dm_exec_requests AS r
  CROSS APPLY sys.fn_PageResCracker(r.page_resource) AS pc  
  CROSS APPLY sys.dm_db_page_info(pc.[db_id], pc.[file_id], pc.page_id, 'DETAILED') AS p
  WHERE UPPER(r.wait_type) like '%PAGELATCH%'
    AND p.database_id = 2 -- tempdb
    AND p.[object_id] IN(3,9,34,40,41,54,55,60,74,75);

-- FIX: ENABLE MEMORY OPTIMIZED TEMPDB, SQL restart is needed

EXEC sys.sp_configure N'show advanced options', 1;
RECONFIGURE;
EXEC sys.sp_configure N'tempdb metadata memory-optimized', 0;
RECONFIGURE;

-- VERIFY THE FEATURE IS ENABLED OR NOT 

SELECT 
 CASE SERVERPROPERTY('IsTempdbMetadataMemoryOptimized')
WHEN 1 THEN 'Enable'
WHEN 0 THEN 'Disable'
END 
AS 'Memory-Optimized TempDB Metadata Status'

