SELECT usecounts AS NumOfExecutions,cacheobjtype,objtype AS ObjectType,size_in_bytes AS PlanSize,[text] AS QueryText
FROM sys.dm_exec_cached_plans
CROSS APPLY sys.dm_exec_sql_text(plan_handle)