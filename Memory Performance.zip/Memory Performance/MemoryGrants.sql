	while (1=1)
	begin
	DECLARE @xmlMessage XML
	DECLARE @x XML
	SELECT @x = @xmlMessage.query('for $WC in /AuditMessage/ActiveParticipant, $S in $WC/RoleIDCode return <RoleIDCode UserID= "{$WC/@UserID }" > { $S/@code } </RoleIDCode> ')
end


	-- one time prepare target table to store query output
	select 
	getdate() as DataCaptureTime, 
	mg.* , 
	st.dbid, st.objectid, st.text as Query_text, 
	qp.query_plan
	into tbl_track_memory_grants
	from sys.dm_exec_query_memory_grants mg
	cross apply sys.dm_exec_sql_text(mg.sql_handle) as st
	cross apply sys.dm_exec_query_plan(mg.plan_handle) as qp
	-- run this portion in a job every 5 or 10 seconds to capture and save the data
	insert into tbl_track_memory_grants
	select 
	getdate() as DataCaptureTime, 
	mg.* , 
	st.dbid, st.objectid, st.text as Query_text, 
	qp.query_plan
	from sys.dm_exec_query_memory_grants mg
	cross apply sys.dm_exec_sql_text(mg.sql_handle) as st
	cross apply sys.dm_exec_query_plan(mg.plan_handle) as qp
	-- examine the data
	select * from tbl_track_memory_grants
